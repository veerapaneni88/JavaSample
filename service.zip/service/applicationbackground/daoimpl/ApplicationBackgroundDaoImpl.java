package us.tx.state.dfps.service.applicationbackground.daoimpl;

import org.springframework.stereotype.Repository;

import us.tx.state.dfps.service.applicationbackground.dao.ApplicationBackgroundDao;

@Repository
public class ApplicationBackgroundDaoImpl implements ApplicationBackgroundDao {
}
