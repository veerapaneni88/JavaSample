package us.tx.state.dfps.service.applicationbackground.dao;

public interface ApplicationBackgroundDao {
}
