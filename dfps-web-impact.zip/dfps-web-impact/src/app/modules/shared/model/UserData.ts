export interface UserData {
    idResource: string;
    idCase?: string;
}
