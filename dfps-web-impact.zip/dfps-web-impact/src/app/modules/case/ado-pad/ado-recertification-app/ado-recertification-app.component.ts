import { Component } from '@angular/core';

@Component({
  selector: 'app-ado-recertification-app',
  templateUrl: './ado-recertification-app.component.html',
  styleUrls: ['./ado-recertification-app.component.css']
})
export class AdoRecertificationAppComponent {

}
