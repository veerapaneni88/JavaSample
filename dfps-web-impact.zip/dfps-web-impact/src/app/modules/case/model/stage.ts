export interface Stage {

    stageId: number;
    stageCode: string;
    name: string;

}