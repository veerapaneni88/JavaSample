export class CodesDto {
    code : string;
    constructor(code){
        this.code = code;
    }
}