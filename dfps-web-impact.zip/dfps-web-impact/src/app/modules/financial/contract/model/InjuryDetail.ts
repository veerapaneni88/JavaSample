import { DropDown } from "dfps-web-lib";

export interface ContractPeriodResponse {
    status: DropDown[];
    pageMode: string;
}