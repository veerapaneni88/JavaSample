 export interface RejectionReason {
    rejectionReasonCode: string;
    rejectionReasonDecode: string;
    rejectedItemId: number;
}